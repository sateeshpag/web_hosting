import java.util.*;

class treesetcl{
  public static void main(String args[]){
    TreeSet tree=new TreeSet();

    tree.add("c");
    tree.add("a");
    tree.add("d");
    tree.add("e");
    tree.add("b");
  
    System.out.println(tree);
  }
}