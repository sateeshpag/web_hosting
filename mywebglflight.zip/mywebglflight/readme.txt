mywebglflight a program by NGUYEN.Chung (freeware 2014)



click on mywebglflightlocal.html to run program in localhost mode using local files.

click or embed in your website mywebglflight.html to run using my online files.(can run alone) 


arrows => turn ,  ctrl+arrows or pageup/pagedown => motor , H => help  , esc => quit 

P => pause , T => change timehour , V => view , shift+arrows => turn head (cockpit view)
 


added forest_chung.html , small hack&slash version with trees,rocs,grass,monsters.